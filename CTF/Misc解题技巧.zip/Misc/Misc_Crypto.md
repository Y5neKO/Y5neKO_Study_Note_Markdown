## 加密方法

Url编码，md5加密，凯撒密码，凯撒密码变异，Rabbit兔子密码，莫尔斯电码，Base64编码，Base32编码（全为大写，以最多6个=填充），Quoted_printable可打印字符编码，标准银河字母，栅栏密码，文字转语音加密，质因数分解，Affine Cipher仿射密码，培根密码（只有a和b），Snow加密（空白字符），whitespace语言，snake/serpent(蛇)加密,SMS PDU(分组数据单元，0-9，A-Z)

## 在线工具

在线分解质因数计算器工具： http://tools.jb51.net/jisuanqi/factor_calc

仿射密码解密： https://aliyunvi.com/affine

单表替换密码词频分析：http://quipqiup.com/

serpent解密：http://serpent.online-domain-tools.com/

